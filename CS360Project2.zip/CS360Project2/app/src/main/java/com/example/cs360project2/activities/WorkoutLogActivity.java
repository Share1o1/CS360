package com.example.cs360project2.activities;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.example.cs360project2.adapter.WorkoutAdapter;
import com.example.cs360project2.databinding.ActivityWorkoutLogBinding;
import com.example.cs360project2.model.WorkoutLog;
import com.example.cs360project2.viewmodel.WorkoutViewModel;
import java.util.ArrayList;

public class WorkoutLogActivity extends AppCompatActivity {

    private ActivityWorkoutLogBinding binding;
    private WorkoutViewModel viewModel;
    private WorkoutAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWorkoutLogBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize ViewModel
        viewModel = new ViewModelProvider(this).get(WorkoutViewModel.class);

        // Setup RecyclerView with empty list
        adapter = new WorkoutAdapter(new ArrayList<>(), workout -> {
            viewModel.deleteWorkout(workout);
        });

        // Add this line to initialize the RecyclerView
        binding.rvWorkouts.setLayoutManager(new LinearLayoutManager(this));
        binding.rvWorkouts.setAdapter(adapter);

        // Observe LiveData with proper list update
        viewModel.getAllWorkouts().observe(this, workouts -> {
            // Replace the entire list
            adapter.updateList(workouts);  // This will now work
        });

        binding.fabAdd.setOnClickListener(v -> {
            // Open add dialog (implement this later)
        });
    }

    // Add dialog implementation here when ready
}