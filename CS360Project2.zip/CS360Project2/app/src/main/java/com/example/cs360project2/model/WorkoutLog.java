package com.example.cs360project2.model;
import androidx.room.Entity;
import androidx.room.PrimaryKey;
@Entity(tableName = "workout_log")

public class WorkoutLog {
    private int id;
    private String exercise;
    private int duration;
    private int calories;
    private String date;

    // Constructor
    public WorkoutLog(int id, String exercise, int duration, int calories, String date) {
        this.id = id;
        this.exercise = exercise;
        this.duration = duration;
        this.calories = calories;
        this.date = date;
    }

    // Getters
    public int getId() { return id; }
    public String getExercise() { return exercise; }
    public int getDuration() { return duration; }
    public int getCalories() { return calories; }
    public String getDate() { return date; }
}