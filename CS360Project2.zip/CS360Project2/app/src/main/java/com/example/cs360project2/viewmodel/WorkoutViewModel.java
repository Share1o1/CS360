package com.example.cs360project2.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import com.example.cs360project2.model.WorkoutLog;
import com.example.cs360project2.repository.WorkoutRepository;
import java.util.List;
import androidx.annotation.NonNull;
import com.example.cs360project2.repository.WorkoutRepository;

public class WorkoutViewModel extends AndroidViewModel {
    private final WorkoutRepository repository;
    private final LiveData<List<WorkoutLog>> allWorkouts;

    public WorkoutViewModel(@NonNull Application application) {
        super(application);
        repository = new WorkoutRepository(application);
        allWorkouts = repository.getAllWorkouts();
    }

    public LiveData<List<WorkoutLog>> getAllWorkouts() {
        return allWorkouts;
    }

    public void insertWorkout(WorkoutLog workout) {
        repository.insertWorkout(workout);
    }

    public void deleteWorkout(WorkoutLog workout) {
        repository.deleteWorkout(workout);
    }
}