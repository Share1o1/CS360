// WorkoutRepository.java
package com.example.cs360project2.repository;

import android.app.Application;
import androidx.lifecycle.LiveData;
import com.example.cs360project2.model.WorkoutLog;
import java.util.List;

public class WorkoutRepository {
    private final WorkoutDao workoutDao;
    private final LiveData<List<WorkoutLog>> allWorkouts;

    public WorkoutRepository(Application application) {
        WorkoutDatabase database = WorkoutDatabase.getDatabase(application);
        workoutDao = database.workoutDao();
        allWorkouts = workoutDao.getAllWorkouts();
    }

    public LiveData<List<WorkoutLog>> getAllWorkouts() {
        return allWorkouts;
    }

    public void insertWorkout(WorkoutLog workout) {
        WorkoutDatabase.databaseWriteExecutor.execute(() -> {
            workoutDao.insert(workout);
        });
    }

    public void deleteWorkout(WorkoutLog workout) {
        WorkoutDatabase.databaseWriteExecutor.execute(() -> {
            workoutDao.delete(workout);
        });
    }
}