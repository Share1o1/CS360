package com.example.cs360project2.activities;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.cs360project2.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.switchmaterial.SwitchMaterial;

public class SmsSettingsActivity extends AppCompatActivity {
    private static final int SMS_PERMISSION_CODE = 101;
    private SwitchMaterial switchSms;
    private MaterialButton btnTest;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_settings);

        switchSms = findViewById(R.id.switchSms);
        btnTest = findViewById(R.id.btnTest);

        // Initial state
        updateUiState();

        // Switch listener
        switchSms.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if(isChecked) {
                requestSmsPermission();
            } else {
                disableSmsNotifications();
            }
        });

        // Test button
        btnTest.setOnClickListener(v -> sendTestNotification());
    }

    private void updateUiState() {
        boolean hasPermission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        switchSms.setChecked(hasPermission);
        btnTest.setEnabled(hasPermission);
    }

    private void requestSmsPermission() {
        ActivityResultLauncher<String> requestPermissionLauncher =
                registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                    if (isGranted) {
                        enableSmsNotifications();
                    } else {
                        handlePermissionDenied();
                    }
                    updateUiState();
                });

        requestPermissionLauncher.launch(Manifest.permission.SEND_SMS);
    }

    private void enableSmsNotifications() {
        // Connect to your notification system
        Toast.makeText(this, "SMS notifications enabled", Toast.LENGTH_SHORT).show();
    }

    private void disableSmsNotifications() {
        // Disconnect from notification system
        Toast.makeText(this, "SMS notifications disabled", Toast.LENGTH_SHORT).show();
    }

    private void handlePermissionDenied() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.SEND_SMS)) {
            // Show explanation
            new AlertDialog.Builder(this)
                    .setTitle("Permission Needed")
                    .setMessage("SMS permission is required to send goal achievement notifications")
                    .setPositiveButton("Retry", (dialog, which) -> requestSmsPermission())
                    .setNegativeButton("Cancel", null)
                    .show();
        } else {
            // Permission denied permanently
            Toast.makeText(this,
                    "Enable SMS in app settings",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void sendTestNotification() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {

            try {
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(
                        "PHONE_NUMBER", // Replace with actual number
                        null,
                        "FitnessTracker: Test notification - You've reached your goal!",
                        null,
                        null);

                Toast.makeText(this, "Test notification sent", Toast.LENGTH_SHORT).show();
            } catch (SecurityException e) {
                Toast.makeText(this, "SMS permission revoked", Toast.LENGTH_SHORT).show();
                updateUiState();
            }
        }
    }
}