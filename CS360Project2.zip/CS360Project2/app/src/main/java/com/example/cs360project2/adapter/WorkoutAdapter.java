package com.example.cs360project2.adapter;

import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.cs360project2.databinding.ItemWorkoutBinding;
import com.example.cs360project2.model.WorkoutLog;

import java.util.ArrayList;
import java.util.List;

public class WorkoutAdapter extends RecyclerView.Adapter<WorkoutAdapter.ViewHolder> {

    private  List<WorkoutLog> workouts;
    private final OnDeleteClickListener onDeleteClickListener;

    public interface OnDeleteClickListener {
        void onDeleteClick(WorkoutLog workout);
    }

    public WorkoutAdapter(List<WorkoutLog> workouts, OnDeleteClickListener listener) {
        this.workouts = new ArrayList<>(workouts);
        this.onDeleteClickListener = listener;
    }
    public void updateList(List<WorkoutLog> newWorkouts) {
        this.workouts.clear();
        this.workouts.addAll(newWorkouts);
        notifyDataSetChanged();}

        @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ItemWorkoutBinding binding = ItemWorkoutBinding.inflate(inflater, parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WorkoutLog workout = workouts.get(position);
        holder.binding.tvExercise.setText(workout.getExercise());
        holder.binding.tvDuration.setText(workout.getDuration() + " mins");
        holder.binding.tvCalories.setText(workout.getCalories() + " kcal");
        holder.binding.tvDate.setText(workout.getDate());

        holder.binding.btnDelete.setOnClickListener(v -> {
            onDeleteClickListener.onDeleteClick(workout);
        });
    }

    @Override
    public int getItemCount() {
        return workouts.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        final ItemWorkoutBinding binding;

        public ViewHolder(ItemWorkoutBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }
}