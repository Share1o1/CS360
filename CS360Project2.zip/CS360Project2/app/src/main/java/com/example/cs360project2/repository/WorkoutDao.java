// In repository package
package com.example.cs360project2.repository;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import com.example.cs360project2.model.WorkoutLog;
import java.util.List;

@Dao
public interface WorkoutDao {
    @Query("SELECT * FROM workout_log")
    LiveData<List<WorkoutLog>> getAllWorkouts();

    @Insert
    void insert(WorkoutLog workout);

    @Delete
    void delete(WorkoutLog workout);
}